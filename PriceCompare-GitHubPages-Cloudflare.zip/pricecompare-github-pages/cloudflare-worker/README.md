# PriceCompare — GitHub Pages + Cloudflare Worker

Questa versione è pensata per un sito statico pubblicato su GitHub Pages.

## Architettura

GitHub Pages (index.html)
        ↓ HTTPS
Cloudflare Worker (/api/search)
        ↓ secret server-side
Sovrn Commerce Price Comparison API
        ↓
offerte → prezzo + negozio + immagine + URL diretto

Le chiavi Sovrn NON vanno inserite in `index.html`. Cloudflare Workers supporta i secrets cifrati e li rende disponibili al Worker tramite `env`; Cloudflare raccomanda di usare secrets per chiavi e token sensibili.

## 1. Pubblica il frontend su GitHub Pages

Carica nella repository GitHub:

- `github-pages/index.html`

Se vuoi usare il root della repository, copia semplicemente `index.html` nella root.

Attiva:
Settings → Pages → Deploy from branch → `main` → `/root`

## 2. Crea il Cloudflare Worker

Puoi usare il dashboard Cloudflare oppure Wrangler.

Con Wrangler:

```bash
cd cloudflare-worker
npm install -D wrangler
npx wrangler login
npx wrangler deploy
```

Prima del deploy imposta i secrets:

```bash
npx wrangler secret put SOVRN_SECRET_KEY
npx wrangler secret put SOVRN_SITE_API_KEY
```

Il primo valore è la Secret Key di Sovrn Commerce.
Il secondo è il Site API Key del sito configurato in Sovrn.

## 3. Configura CORS

Apri `worker.js` e sostituisci:

```js
const ALLOWED_ORIGINS = [
  "https://TUO-USERNAME.github.io",
  "https://TUO-DOMINIO-CUSTOM.it"
];
```

con il tuo dominio GitHub Pages.

Esempio:

```js
const ALLOWED_ORIGINS = [
  "https://mario.github.io"
];
```

Poi ridistribuisci:

```bash
npx wrangler deploy
```

## 4. Collega GitHub Pages al Worker

Apri `github-pages/index.html` e sostituisci:

```js
const API_BASE_URL = "https://TUO-WORKER.workers.dev";
```

con l'URL reale del Worker.

Esempio:

```js
const API_BASE_URL = "https://pricecompare-api.mario.workers.dev";
```

Fai commit e push su GitHub.

## 5. Test

Apri:

```text
https://TUO-WORKER.workers.dev/
```

Dovresti vedere un JSON che indica che il Worker è operativo.

Poi prova:

```text
https://TUO-WORKER.workers.dev/api/search?q=iPhone%2016
```

Se i secrets sono configurati correttamente, il Worker restituisce le offerte.

## Importante: "tutti i siti"

Nessun singolo servizio può garantire letteralmente tutti i negozi presenti su Internet. Questa versione mostra tutte le offerte che il provider configurato restituisce per quella ricerca, fino al limite richiesto.

Sovrn dichiara che il Price Comparison API cerca prodotti tramite barcode, URL o parole chiave, restituisce offerte raggruppate per merchant e supporta il mercato `eur_it`.

Se in futuro vuoi una copertura più ampia, il Worker può essere esteso per combinare più provider in un unico risultato.

## Sicurezza

NON inserire mai:

- `SOVRN_SECRET_KEY`
- API key private
- token

dentro `index.html`, JavaScript pubblico o repository GitHub.

I secrets devono restare nel Worker.
