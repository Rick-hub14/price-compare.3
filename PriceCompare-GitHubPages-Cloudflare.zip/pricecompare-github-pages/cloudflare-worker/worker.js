const ALLOWED_ORIGINS = [
  "https://TUO-USERNAME.github.io",
  "https://TUO-DOMINIO-CUSTOM.it"
];

const SOVRN_BASE = "https://comparisons.sovrn.com/api/affiliate/v3.5/sites";

function corsHeaders(origin) {
  const allowed = ALLOWED_ORIGINS.includes(origin);
  return {
    "Access-Control-Allow-Origin": allowed ? origin : ALLOWED_ORIGINS[0],
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Accept",
    "Vary": "Origin",
    "Content-Type": "application/json; charset=utf-8",
  };
}

function json(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: corsHeaders(origin),
  });
}

function first(...values) {
  return values.find(v => v !== undefined && v !== null && v !== "");
}

function normalizeOffer(raw) {
  const merchant = raw.merchant || raw.store || raw.retailer || raw.salePlace || {};
  const priceObj = raw.price || raw.salePrice || raw.offerPrice || {};
  const image = first(raw.image, raw.imageUrl, raw.productImage, raw.image_url, raw.thumbnail);
  const url = first(raw.url, raw.link, raw.productUrl, raw.product_url, raw.deepLink, raw.plainlink);

  const price = typeof priceObj === "object"
    ? first(priceObj.value, priceObj.amount, priceObj.price)
    : priceObj;

  const currency = typeof priceObj === "object"
    ? first(priceObj.currency, raw.currency, "EUR")
    : first(raw.currency, "EUR");

  return {
    title: first(raw.title, raw.productTitle, raw.name, "Prodotto"),
    store: typeof merchant === "string"
      ? merchant
      : first(merchant.name, merchant.title, raw.merchantName, raw.storeName, "Negozio"),
    price: price !== undefined ? Number(price) : null,
    currency,
    shipping: first(raw.shipping, raw.shippingCost, raw.delivery, ""),
    availability: first(raw.availability, raw.stock, raw.inStock, ""),
    image,
    thumbnail: first(raw.thumbnail, raw.thumbnailUrl),
    url
  };
}

function extractOffers(payload) {
  if (Array.isArray(payload)) return payload;
  return first(
    payload?.offers,
    payload?.results,
    payload?.products,
    payload?.items,
    payload?.data
  ) || [];
}

function extractProduct(payload) {
  const product = first(payload?.product, payload?.productInfo, payload?.item);
  if (!product) return null;
  return {
    title: first(product.title, product.name),
    image: first(product.image, product.imageUrl, product.thumbnail)
  };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }

    const url = new URL(request.url);

    if (url.pathname === "/") {
      return json({
        ok: true,
        service: "PriceCompare API",
        message: "Cloudflare Worker operativo."
      }, 200, origin);
    }

    if (url.pathname !== "/api/search" || request.method !== "GET") {
      return json({ error: "Endpoint non trovato." }, 404, origin);
    }

    const query = (url.searchParams.get("q") || "").trim();
    if (query.length < 2) {
      return json({ error: "Inserisci almeno 2 caratteri." }, 400, origin);
    }

    if (query.length > 150) {
      return json({ error: "Ricerca troppo lunga." }, 400, origin);
    }

    if (!env.SOVRN_SECRET_KEY || !env.SOVRN_SITE_API_KEY) {
      return json({
        error: "Il Worker non è configurato: mancano SOVRN_SECRET_KEY e/o SOVRN_SITE_API_KEY."
      }, 500, origin);
    }

    const market = "eur_it";
    const apiUrl = new URL(`${SOVRN_BASE}/${encodeURIComponent(env.SOVRN_SITE_API_KEY)}/compare/prices/${market}/by/accuracy`);
    apiUrl.searchParams.set("search-keywords", query);
    apiUrl.searchParams.set("limit", "100");

    try {
      const upstream = await fetch(apiUrl.toString(), {
        method: "GET",
        headers: {
          "Authorization": `secret ${env.SOVRN_SECRET_KEY}`,
          "Accept": "application/json"
        }
      });

      const text = await upstream.text();
      let payload;
      try { payload = JSON.parse(text); }
      catch { payload = { raw: text }; }

      if (!upstream.ok) {
        return json({
          error: "Il servizio di confronto ha restituito un errore.",
          status: upstream.status,
          details: payload
        }, 502, origin);
      }

      const rawOffers = extractOffers(payload);
      const offers = rawOffers
        .map(normalizeOffer)
        .filter(o => o.url && /^https?:\/\//i.test(o.url))
        .sort((a, b) => {
          if (a.price === null) return 1;
          if (b.price === null) return -1;
          return a.price - b.price;
        });

      return json({
        ok: true,
        query,
        market,
        count: offers.length,
        product: extractProduct(payload),
        offers
      }, 200, origin);

    } catch (error) {
      return json({
        error: "Errore di rete verso il servizio di confronto.",
        details: String(error?.message || error)
      }, 502, origin);
    }
  }
};
